Flex Chart source code
----------------------

Flex projects can be exported and imported as .zip files.

The Flex charts project is the Charts.zip file. Use Flex Builder to import this zip file.