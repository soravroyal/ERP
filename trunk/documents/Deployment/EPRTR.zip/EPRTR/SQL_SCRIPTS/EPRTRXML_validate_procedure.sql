USE [EPRTRxml]
GO

if object_id('dbo.validate_xml_data')is not null DROP PROCEDURE dbo.validate_xml_data
go
create procedure [dbo].[validate_xml_data]
as
begin

--Validating if previous nationalid can be found
print('')
print('Validating previous nationalids and previous reporting year given in xml file')

if object_id('EPRTRxml.dbo.validate_prevnationalid')is not null DROP TABLE EPRTRxml.dbo.validate_prevnationalid
select	a.prevnationalid,
		a.prevreportingyear,
		c.LOV_CountryID 
into EPRTRxml.dbo.validate_prevnationalid
from EPRTRxml.dbo.FacilityReport a
inner join
		EPRTRxml.dbo.POLLUTANTRELEASEANDTRANSFERREPORT b
		on b.POLLUTANTRELEASEANDTRANSFERREPORTID = a.POLLUTANTRELEASEANDTRANSFERREPORTID
inner join
	EPRTRmaster.dbo.LOV_COUNTRY c
	on c.Code = b.CountryID
where a.prevreportingyear <> b.reportingyear 

alter table EPRTRxml.dbo.validate_prevnationalid add nationalid nvarchar(255)

update EPRTRxml.dbo.validate_prevnationalid
set nationalid = c.NationalID
from
EPRTRmaster.dbo.vAT_POLLUTANTRELEASEANDTRANSFERREPORT b
inner join
	EPRTRmaster.dbo.FacilityReport c
	on b.POLLUTANTRELEASEANDTRANSFERREPORTID = c.POLLUTANTRELEASEANDTRANSFERREPORTID
where EPRTRxml.dbo.validate_prevnationalid.prevnationalid = c.NationalID 
and EPRTRxml.dbo.validate_prevnationalid.prevreportingyear = b.ReportingYear
and EPRTRxml.dbo.validate_prevnationalid.LOV_CountryID = b.LOV_CountryID


if (select count(1) from EPRTRxml.dbo.validate_prevnationalid where nationalID is null) = 0 
print('All previous nationalIDs can be found in E-PRTR database')
else
begin
declare 
@txt1 nvarchar(250),
@txt2 nvarchar(250) 
DECLARE 
fac_Cursor CURSOR FOR
SELECT PrevNationalID,prevreportingyear 
FROM EPRTRxml.dbo.validate_PrevNationalID 
where nationalid is null order by cast (PrevNationalID as int);
OPEN fac_Cursor;
FETCH NEXT FROM fac_Cursor into @txt1,@txt2;
print('Previous nationalids that does not exist for the given previous reporting year')
print('The listed facilities will be considered new facilities when imported into the EPRTR-system!')
WHILE @@FETCH_STATUS = 0
BEGIN
print('Previous NationalID: ' + @txt1 + ' does not exist in the report from '+ @txt2)
FETCH NEXT FROM fac_Cursor into @txt1,@txt2;
END;
CLOSE fac_Cursor;
DEALLOCATE fac_Cursor;
end

if object_id('EPRTRxml.dbo.validate_prevnationalid')is not null DROP TABLE EPRTRxml.dbo.validate_prevnationalid




--Validating if previous nationalid returns multiple records
print('')
print('')
print('Validating if previous nationalid return multiple records')
if object_id('EPRTRxml.dbo.validate_facility')is not null DROP TABLE EPRTRxml.dbo.validate_facility
select c.facilityreportID,count(1) as count_facilityid into EPRTRxml.dbo.validate_facility
from 
EPRTRmaster.dbo.FACILITY a
inner join 
EPRTRmaster.dbo.FacilityReport d
on  a.facilityid = d.facilityid
inner join
EPRTRxml.dbo.FacilityReport c
on c.PrevNationalID=d.NationalID
inner join
EPRTRmaster.dbo.POLLUTANTRELEASEANDTRANSFERREPORT e
on c.PrevReportingYear=e.ReportingYear and
e.POLLUTANTRELEASEANDTRANSFERREPORTID = d.POLLUTANTRELEASEANDTRANSFERREPORTID
inner join
EPRTRxml.dbo.POLLUTANTRELEASEANDTRANSFERREPORT f 
on c.POLLUTANTRELEASEANDTRANSFERREPORTID = f.POLLUTANTRELEASEANDTRANSFERREPORTID
where
e.LOV_CountryID = 
(select g.LOV_CountryID from EPRTRmaster.dbo.LOV_COUNTRY g where g.Code = f.CountryID)
group by c.facilityreportID

alter table EPRTRxml.dbo.validate_facility add PrevNationalID nvarchar(255)

update EPRTRxml.dbo.validate_facility set PrevNationalID = (select PrevNationalID
from EPRTRxml.dbo.FacilityReport c where c.facilityreportid = EPRTRxml.dbo.validate_facility.facilityreportid)


if (select count(1) from EPRTRxml.dbo.validate_facility where count_facilityid <> 1) = 0 
print('No previous nationalids return multiple records')
else
begin
DECLARE 
fac_Cursor CURSOR FOR
SELECT PrevNationalID, count_facilityid 
FROM EPRTRxml.dbo.validate_facility
WHERE count_facilityid <> 1 order by PrevNationalID;
OPEN fac_Cursor;
FETCH NEXT FROM fac_Cursor into @txt1,@txt2;
print('Previous nationalids that return multiple records')
WHILE @@FETCH_STATUS = 0
BEGIN
print('Previous NationalID: ' +@txt1 + ' Number of records: ' + @txt2)
FETCH NEXT FROM fac_Cursor into @txt1,@txt2;
END;
CLOSE fac_Cursor;
DEALLOCATE fac_Cursor;
end
if object_id('EPRTRxml.dbo.validate_facility')is not null DROP TABLE EPRTRxml.dbo.validate_facility


--Validating if reported coordinates are within country polygons
print('')
print('')
print('Validating if reported coordinates are within country polygons')

if object_id('EPRTRxml.dbo.validate_coordinates')is not null DROP TABLE EPRTRxml.dbo.validate_coordinates


------------------------------------------------------------------------------
--	Geo-coding of NUTS regions
------------------------------------------------------------------------------


declare @UNKNOWN int
select @UNKNOWN = LOV_RiverBasinDistrictID 
	from EPRTRmaster.dbo.LOV_RIVERBASINDISTRICT 
	where Code = 'UNKNOWN'

declare @LOV_M int
select @LOV_M = LOV_StatusID  
	from EPRTRmaster.dbo.LOV_STATUS 
	where Code = 'MISSING'

declare @LOV_O int
select @LOV_O = LOV_StatusID  
	from EPRTRmaster.dbo.LOV_STATUS 
	where Code = 'OUTSIDE'

declare @LOV_UNDEFINED int
select @LOV_UNDEFINED = LOV_StatusID  
	from EPRTRmaster.dbo.LOV_STATUS 
	where Code = 'OUTSIDE'

declare @LOV_VALID int
select @LOV_VALID = LOV_StatusID  
	from EPRTRmaster.dbo.LOV_STATUS 
	where Code = 'VALID'


select  fr.nationalid,
		pt.PollutantReleaseAndTransferReportID,
		geometry::STGeomFromText('POINT(' + 
		cast(fr.LongitudeMeasure as varchar(32)) + ' '+ 
		cast(fr.LatitudeMeasure as varchar(32)) + ')', 4326) as GeographicalCoordinate,
	case 
		when isnull(fr.LongitudeMeasure,0 ) = 0 then @LOV_M
		when isnull(fr.LatitudeMeasure,0 ) = 0 then @LOV_M
		else @LOV_O end as LOV_StatusID,
		null as LOV_NUTSRegionID,
		null as LOV_RiverBasinDistrictID
into EPRTRxml.dbo.validate_coordinates
from EPRTRxml.dbo.FACILITYREPORT fr
inner join 
	EPRTRxml.dbo.POLLUTANTRELEASEANDTRANSFERREPORT pt
on	pt.PollutantReleaseAndTransferReportID = fr.PollutantReleaseAndTransferReportID


------------------------------------------------------------------------------
--	Geo-coding of NUTS regions
------------------------------------------------------------------------------
	
update EPRTRxml.dbo.validate_coordinates
set 
	LOV_NUTSRegionID = m.LOV_NUTSRegionID,
	LOV_StatusID = @LOV_VALID
from EPRTRxml.dbo.validate_coordinates frep
inner join 
	EPRTRxml.dbo.POLLUTANTRELEASEANDTRANSFERREPORT pt
on	pt.PollutantReleaseAndTransferReportID = frep.PollutantReleaseAndTransferReportID 
inner join
	EPRTRmaster.dbo.LOV_COUNTRY g
	on g.Code = pt.CountryID
inner join (
	select
		LOV_CountryID as LOV_CountryID, 
		nuts.LOV_NUTSRegionID as LOV_NUTSRegionID,
		geom as Shape
	from
		EPRTRmaster.dbo.LOV_NUTSREGION nuts
	inner join
		EPRTRmaster.dbo.NUTS_RG nr
	on	nuts.Code = nr.NUTS_ID
	and nr.STAT_LEVL_ = 2 
	) m
on	g.LOV_CountryID = m.LOV_CountryID
and frep.GeographicalCoordinate.STWithin(m.Shape) = 1
where frep.LOV_StatusID = @LOV_UNDEFINED

------------------------------------------------------------------------------
--	Geo-coding of river basin districts
------------------------------------------------------------------------------


update EPRTRxml.dbo.validate_coordinates
set 
	LOV_RiverBasinDistrictID = m.LOV_RiverBasinDistrictID,
	LOV_StatusID = @LOV_VALID
from EPRTRxml.dbo.validate_coordinates frep
inner join 
	EPRTRxml.dbo.POLLUTANTRELEASEANDTRANSFERREPORT pt
on	pt.PollutantReleaseAndTransferReportID = frep.PollutantReleaseAndTransferReportID
inner join
	EPRTRmaster.dbo.LOV_COUNTRY g
	on g.Code = pt.CountryID
inner join (
	select
		LOV_CountryID as LOV_CountryID, 
		r.LOV_RiverBasinDistrictID as LOV_RiverBasinDistrictID,
		geom as Shape
	from
		EPRTRmaster.dbo.LOV_RIVERBASINDISTRICT r
	inner join
		EPRTRmaster.dbo.RBD s
	on	s.MSCD_RBD = r.Code
	) m
on	g.LOV_CountryID = m.LOV_CountryID
and frep.GeographicalCoordinate.STWithin(m.Shape) = 1
where frep.LOV_StatusID in (@LOV_UNDEFINED, @LOV_VALID)

if (
	select count(1) 
	from EPRTRxml.dbo.validate_coordinates
	WHERE 
		LOV_StatusID in (select LOV_StatusID from EPRTRmaster.dbo.LOV_STATUS where Code in( 'OUTSIDE','MISSING'))
	) = 0
print('All reported coordinates are OK')
else
begin
DECLARE 
fac_Cursor CURSOR FOR
	SELECT NationalID, LOV_StatusID 
	FROM EPRTRxml.dbo.validate_coordinates
	WHERE LOV_StatusID in (select LOV_StatusID from EPRTRmaster.dbo.LOV_STATUS where Code in( 'OUTSIDE','MISSING')) order by NationalID;
OPEN fac_Cursor;
FETCH NEXT FROM fac_Cursor into @txt1, @txt2
print('Facilities with coordinates outside country')
print('')
WHILE @@FETCH_STATUS = 0
BEGIN
if @txt2 = (select LOV_StatusID from EPRTRmaster.dbo.LOV_STATUS where Code = 'OUTSIDE')
print('NationalID: ' +@txt1 + ' Coordinates not within country polygon')
else
print('NationalID: ' +@txt1 + ' Coordinates zero or not reported')
FETCH NEXT FROM fac_Cursor into @txt1, @txt2;
END;
CLOSE fac_Cursor;
DEALLOCATE fac_Cursor;
end
if object_id('EPRTRxml.dbo.validate_coordinates')is not null DROP TABLE EPRTRxml.dbo.validate_coordinates

end


